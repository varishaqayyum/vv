# Statement Builder Pro

Rebuild the website pages and functionality that were previously created, using the existing project and the intact Supabase database. Do not redesign the site from scratch and do not add unnecessary features.

The website is a personal statement platform for UK university applicants, focused on helping students develop and improve their own personal statements rather than writing statements for them.

Recreate the main website structure in the existing Editorial study-desk style:

1. HOMEPAGE

* Clear explanation of the personal statement service.

* Primary CTA: "Get your personal statement checked".

* Explain that users are guided to improve their own ideas and writing, not have a personal statement written for them.

* Keep the existing navigation and pricing structure where possible.

2. AUTHENTICATION + ONBOARDING

* Users must be able to sign up and log in using the existing Supabase setup.

* After logging in, users should be taken through the existing onboarding flow.

* Ask what degree/course they are applying for and their year of entry.

* Save these details to the user's account/database.

* After onboarding, take the user directly to their personal statement dashboard.

* Make sure the logged-in state persists correctly and users do not get stuck after signing in.

3. PERSONAL STATEMENT DASHBOARD

* Recreate the three separate UCAS personal statement question sections.

* Each question must have its own text box.

* The three answers together have a TOTAL character limit of 4,000 characters.

* Show a clear combined character counter, e.g. "1,250 / 4,000".

* Do NOT give each question its own 4,000-character allowance.

* Users should be able to save their answers and return to them later.

* Clearly label the three questions and make the page easy to use.

* Do not automatically write answers for users.

4. CHECKING FLOW

* After completing their statement, users should be able to access the checking/feedback section.

* Keep this connected to the existing account and statement data.

* Do not implement payment functionality yet unless it already exists and is required for the current pages.

* The free personal statement checking option should remain separate from the paid human review option.

5. IMPORTANT

* Use the existing Supabase database/schema rather than creating an unnecessary new database.

* Preserve the existing authentication and database setup.

* Fix routing so every button takes the user to the correct page.

* Make sure refreshing the page does not break authentication or lose saved data.

* Make sure the project builds successfully when finished.

* Do not remove working functionality.

* Do not make unrelated visual changes.

* If a previous component or page is missing because of the rollback, recreate it cleanly rather than leaving placeholder pages.

Before finishing, verify that the full flow works:

Homepage → Get Personal Statement Checked → Sign Up/Login → Course + Entry Year → Dashboard → 3 UCAS questions → combined 4,000-character counter → Save → return to saved statement.

This project was built with [Lovable](https://lovable.dev).

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/7ea99e78-ff22-4651-80c7-fc39791652fd).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
